//
//  Model.swift
//  GiaoDien
//
//  Created by Cuong on 12/2/18.
//  Copyright © 2018 Cuong. All rights reserved.
//

import Foundation
struct NewInfo {
    var id = ""
    var urlImage = ""
    var urlName = ""
    var AddrStore = ""
    var content = ""
    var vido = ""
    var kinhdo = ""
    
}

struct NewMenu {
    var id = ""
    var urlimg = ""
    var namefood = ""
    var price = ""
}

struct UserFood {
    var id = ""
    var uid = ""
}
struct UserSaved {
    var _id = ""
    var idStore = ""
    var urlImage = ""
    var ImgName = ""
    var address =  ""
    var kinhdo = ""
    var vido = ""
    var contents = ""
    
}
struct TableSave {
    var idStore = ""
    var urlImage = ""
    var ImgName = ""
    var address = ""
    var kinhdo = ""
    var vido = ""
    var content = ""
    
}
struct Comments {
    var id = ""
    var uid = ""
    var content = ""
    var name = ""
    var imgprofile = ""
}
struct StoreFind {
    var _id = ""
    var idStore = ""
    var urlImage = ""
    var ImgName = ""
    var address =  ""
    var kinhdo = ""
    var vido = ""
    var contents = ""
}

struct MenuUser {
    var urlimg = ""
    var namefood = ""
    var price = ""
}
struct StoreShare {
    var id = ""
    var urlImage:String = ""
    var ImgName:String = ""
    var address:String = ""
    var contents:String = ""
}
struct notifi {
    var title = ""
    var des = ""
}
