//
//  NotificationViewController.swift
//  GiaoDien
//
//  Created by TrucRocket on 12/26/18.
//  Copyright © 2018 Cuong. All rights reserved.
//

import UIKit

class NotificationViewController: UIViewController,UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var NotificaTableView: UITableView!
    
    var noti:[notifi] = [
    notifi(title: "Tham gia ngay và nhận quà", des: "Hay chia sẻ quán ăn mà bạn biết cho chúng tôi để nhận được nhiều phân quà hấp dẫn"),
    notifi(title: "Lưu địa chỉ quán ăn mà bạn muốn", des: "Hãy thử lưu một địa chỉ quán ăn bạn sẽ nhận được xu từ chúng tối")
    ]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return noti.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = NotificaTableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath)
        let img = cell.viewWithTag(10) as! UIImageView
        let title = cell.viewWithTag(11) as! UILabel
        let subtitle = cell.viewWithTag(12) as! UILabel
        
        title.text = noti[indexPath.row].title
        subtitle.text = noti[indexPath.row].des
        img.image = UIImage(named: "SaveNotification")
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let message = noti[indexPath.row].des
        let alert:UIAlertController = UIAlertController(title: "Thông báo của bạn", message: message, preferredStyle: .alert)
        
        let btnLogin:UIAlertAction = UIAlertAction(title: "OK", style: .destructive) { (btnLogin) in
            
        }
        
        alert.addAction(btnLogin)
        
        present(alert, animated: true, completion: nil)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        NotificaTableView.dataSource = self
        NotificaTableView.delegate = self
        // Do any additional setup after loading the view.
    }
    
}
