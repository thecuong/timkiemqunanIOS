//
//  AddStoreViewController.swift
//  GiaoDien
//
//  Created by TrucRocket on 6/23/19.
//  Copyright © 2019 Cuong. All rights reserved.
//

import UIKit
import Firebase

class AddStoreViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let userID = Auth.auth().currentUser?.uid
    var myTableData = [StoreShare]()
    
    @IBOutlet weak var myTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.topItem?.leftBarButtonItem = UIBarButtonItem(title: "Hủy", style: .done, target: self, action: #selector(PopController))
        navigationController?.navigationBar.topItem?.rightBarButtonItem = UIBarButtonItem(title: "Thêm", style: .done, target: self, action: #selector(updataPost))
        navigationController?.navigationBar.topItem?.title = "Đóng góp của bạn"
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        loadStoreUser()
    }
    @objc func PopController() {
        dismiss(animated: true, completion: nil)
    }
    @objc func updataPost() {
        let storyboard = UIStoryboard(name: "AddStore", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "DetailAddViewController") as! DetailAddViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myTableData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let myCell = myTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let myImgView = myCell.viewWithTag(10) as! UIImageView
        let myLblName = myCell.viewWithTag(11) as! UILabel
        let myLblAddr = myCell.viewWithTag(12) as! UILabel
        let mylblContent = myCell.viewWithTag(13) as! UILabel
        myLblName.text = myTableData[indexPath.row].ImgName
        myLblAddr.text = myTableData[indexPath.row].address
        mylblContent.text = myTableData[indexPath.row].contents
        let myURl = myTableData[indexPath.row].urlImage
        if myURl != "" {
            loadImg(url: myURl, to: myImgView)
        }
        return myCell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 130
    }
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .destructive, title: "Xoá") { (action, indexPath) in
            let url = URL(string: "http://localhost:3000/userRemoveStore")
            var req = URLRequest(url: url!)
            req.httpMethod = "POST"
            
            let postString = "IDStore=\(self.myTableData[indexPath.row].id)"
            req.httpBody = postString.data(using: .utf8)
            URLSession.shared.dataTask(with: req, completionHandler: { (data, res, err) in
                print(data!)
            }).resume()
            self.myTableData.remove(at: indexPath.row)
            self.myTableView.reloadData()
        }
        let edit = UITableViewRowAction(style: .normal, title: "Thay đổi") { (action, indexPath) in
           
        }
        edit.backgroundColor = UIColor.blue
        return [delete, edit]
    }
    func loadImg(url: String, to imageview: UIImageView) {
        let url = URL(string: url)
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            guard let data = data else
            {
                return
            }
            DispatchQueue.main.async {
                imageview.image = UIImage(data: data)
            }
            }.resume()
        
    }
    func loadStoreUser()
    {
        myTableData = [StoreShare]()
        var myMenu = StoreShare()
        let url = URL(string: "http://localhost:3000/userReadShareStore")
        var req = URLRequest(url: url!)
        req.httpMethod = "POST"
        req.httpBody = "uID=\(userID!)".data(using: .utf8)
        let task = URLSession.shared.dataTask(with: req) { (data, response, error) in
            if error != nil {
                print("error herr...")
                print(error!)
            }
            else {
                if let content = data {
                    do {
                        let myJson = try JSONSerialization.jsonObject(with: content, options: .mutableContainers)
                        if let jsonData = myJson as? [String:Any] {
                            if let myResult = jsonData["result"] as? [[String:Any]] {
                                for value in myResult {
                                    if let id = value["_id"] as? String {
                                        myMenu.id = id
                                    }
                                    if let urlImage = value["urlImage"] as? String {
                                        myMenu.urlImage = urlImage
                                    }
                                    if let ImgName = value["ImgName"] as? String {
                                        myMenu.ImgName = ImgName
                                    }
                                    if let address = value["address"] as? String {
                                        myMenu.address = address
                                    }
                                    if let contents = value["contents"] as? String {
                                        myMenu.contents = contents
                                    }
                                    self.myTableData.append(myMenu)
                                }
                                DispatchQueue.main.async {
                                    self.myTableView.reloadData()
                                }
                            }
                        }
                    }
                    catch {
                        
                    }
                }
                
            }
        }
        task.resume()
    }

}
