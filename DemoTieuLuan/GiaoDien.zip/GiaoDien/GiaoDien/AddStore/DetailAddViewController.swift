//
//  DetailAddViewController.swift
//  GiaoDien
//
//  Created by TrucRocket on 7/9/19.
//  Copyright © 2019 Cuong. All rights reserved.
//

import UIKit
import Firebase
var myMenu = MenuUser()
var isCheck:Bool = false
class DetailAddViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate, UITableViewDataSource, UITableViewDelegate  {
    
    var checkUpdate:Bool = false
    
    @IBOutlet weak var imageStore: UIImageView!
    @IBOutlet weak var txtViewNameStore: UITextView!
    @IBOutlet weak var txtViewContentStore: UITextView!
    @IBOutlet weak var txtViewAddrStore: UITextView!
    
    var alertContoller:UIAlertController?
    var picker = UIImagePickerController()
    var StatusImage: Data?
    var urlImgaString:String = ""
    
    let uid = Auth.auth().currentUser?.uid
    @IBOutlet weak var myTableViewMenu: UITableView!
    var myTableViewMenuData = [MenuUser]()
    override func viewDidLoad() {
        super.viewDidLoad()
        picker.delegate = self
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        if isCheck {
            myTableViewMenuData.append(myMenu)
            myTableViewMenu.reloadData()
            isCheck = false
        }
        
    }
    @IBAction func AddImageStore(_ sender: Any) {
        alertContoller = UIAlertController(title: "Lấy Ảnh", message: "Chọn nơi bạn muốn lấy ảnh", preferredStyle: .actionSheet)
        let cameraAction = UIAlertAction(title: "Camera", style: .default) { (action) in
            print("Bạn Chọn Camera")
            self.onpenCamera()
        }
        let photoAction = UIAlertAction(title: "Thư Viện Ảnh", style: .default) { (action) in
            print("Bạn Chọn Thư Viện Ảnh")
            self.onpenPhotos()
        }
        alertContoller?.addAction(cameraAction)
        alertContoller?.addAction(photoAction)
        alertContoller?.view.tintColor = UIColor.magenta
        self.present(alertContoller!, animated: true) {
            print("present")
            
        }
    }
    func onpenCamera() {
        picker = UIImagePickerController()
        if(UIImagePickerController.isSourceTypeAvailable(.camera)==false) {
            return
        }
        picker.delegate = self
        picker.allowsEditing = true
        picker.sourceType = .camera
        
        
        self.present(picker, animated: true) {
            print("presented pickerController")
        }
    }
    func onpenPhotos() {
        picker = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = true
        picker.sourceType = .photoLibrary
        self.present(picker, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let chooseIamge: UIImage = info[UIImagePickerController.InfoKey.editedImage] as! UIImage
        let imageData: NSData = chooseIamge.pngData()! as NSData
        StatusImage = imageData as Data
        self.imageStore.image = chooseIamge
        self.imageStore.clipsToBounds = true
        self.imageStore.contentMode = .scaleToFill
        
        let ImageName = UUID().uuidString
        
        let StorageRef = Storage.storage().reference().child("ImgaUserShare").child("\(ImageName).png")
        
        if let uploadData = self.imageStore.image!.pngData() {
            StorageRef.putData(uploadData, metadata: nil, completion: { (metaData, error) in
                if error != nil{
                    print(error!)
                    return
                }
                
                StorageRef.downloadURL { (url, error) in
                    if let downloadURL = url?.absoluteString {
                        self.urlImgaString = downloadURL
                    }
                    else {
                        
                        return
                    }
                }
                
                
            })
        }
        
        picker.dismiss(animated: true, completion: nil)
        
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
        print("canceled piker")
    }
    @IBAction func AddMenu(_ sender: Any) {
        let storyboard = UIStoryboard(name: "AddStore", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "UpdataMenuViewController") as! UpdataMenuViewController
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func SubmitPost(_ sender: Any) {
        var data: [String: Any] = [
            "uID": uid!,
            "addminCheck": "No",
            "urlImage":urlImgaString,
            "ImgName":txtViewNameStore.text!,
            "address":txtViewAddrStore.text!,
            "contents":txtViewContentStore.text!,
            "MoreContents": []
        ]
        for index in 0..<myTableViewMenuData.count {
            
            let item: [String: Any] = [
                "ImgFood": myTableViewMenuData[index].urlimg,
                "ImgNameFood":myTableViewMenuData[index].namefood,
                "Price":myTableViewMenuData[index].price
            ]
            
            // get existing items, or create new array if doesn't exist
            var existingItems = data["MoreContents"] as? [[String: Any]] ?? [[String: Any]]()
            
            // append the item
            existingItems.append(item)
            
            // replace back into `data`
            data["MoreContents"] = existingItems
        }
        let jsondata = try? JSONSerialization.data(withJSONObject: data)
        print(data)
        print(jsondata!)
        print("asdg")
        //up len server
        let url = URL(string: "http://localhost:3000/useAddStore")
        var req = URLRequest(url: url!)
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpMethod = "POST"
        req.httpBody = jsondata
        URLSession.shared.dataTask(with: req, completionHandler: { (data, res, err) in
            print(String(data: data!, encoding: .utf8)!)
        }).resume()
        //
        navigationController?.popViewController(animated: true)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myTableViewMenuData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let myCell = myTableViewMenu.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        let myImgV = myCell.viewWithTag(10) as! UIImageView
        let myLbName = myCell.viewWithTag(11) as! UILabel
        let myLblPrice = myCell.viewWithTag(12) as! UILabel
        
        myLbName.text = myTableViewMenuData[indexPath.row].namefood
        myLblPrice.text = myTableViewMenuData[indexPath.row].price
        
        let myURl = myTableViewMenuData[indexPath.row].urlimg
        if myURl != "" {
            loadImg(url: myURl, to: myImgV)
        }
        
        return myCell
    }
    func loadImg(url: String, to imageview: UIImageView) {
        let url = URL(string: url)
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            guard let data = data else
            {
                return
            }
            DispatchQueue.main.async {
                imageview.image = UIImage(data: data)
            }
            }.resume()
        
    }
    @IBAction func Cancel(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
}
