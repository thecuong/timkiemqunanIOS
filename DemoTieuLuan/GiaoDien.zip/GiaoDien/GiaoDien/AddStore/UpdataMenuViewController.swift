//
//  UpdataMenuViewController.swift
//  GiaoDien
//
//  Created by TrucRocket on 7/9/19.
//  Copyright © 2019 Cuong. All rights reserved.
//

import UIKit
import Firebase
class UpdataMenuViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var imageViewFood: UIImageView!
    @IBOutlet weak var txtPrice: UITextField!
    @IBOutlet weak var txtNameFood: UITextField!
    
    var alertContoller:UIAlertController?
    var picker = UIImagePickerController()
    var StatusImage: Data?
    var urlImgaString:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        picker.delegate = self
    }
    
    @IBAction func btnAddImage(_ sender: Any) {
        alertContoller = UIAlertController(title: "Lấy Ảnh", message: "Chọn nơi bạn muốn lấy ảnh", preferredStyle: .actionSheet)
        let cameraAction = UIAlertAction(title: "Camera", style: .default) { (action) in
            print("Bạn Chọn Camera")
            self.onpenCamera()
        }
        let photoAction = UIAlertAction(title: "Thư Viện Ảnh", style: .default) { (action) in
            print("Bạn Chọn Thư Viện Ảnh")
            self.onpenPhotos()
        }
        alertContoller?.addAction(cameraAction)
        alertContoller?.addAction(photoAction)
        alertContoller?.view.tintColor = UIColor.magenta
        self.present(alertContoller!, animated: true) {
            print("present")
            
        }
    }
    func onpenCamera() {
        picker = UIImagePickerController()
        if(UIImagePickerController.isSourceTypeAvailable(.camera)==false) {
            return
        }
        picker.delegate = self
        picker.allowsEditing = true
        picker.sourceType = .camera
        
        
        self.present(picker, animated: true) {
            print("presented pickerController")
        }
    }
    func onpenPhotos() {
        picker = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = true
        picker.sourceType = .photoLibrary
        self.present(picker, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let chooseIamge: UIImage = info[UIImagePickerController.InfoKey.editedImage] as! UIImage
        let imageData: NSData = chooseIamge.pngData()! as NSData
        StatusImage = imageData as Data
        self.imageViewFood.image = chooseIamge
        self.imageViewFood.clipsToBounds = true
        self.imageViewFood.contentMode = .scaleToFill
        
        
        let ImageName = UUID().uuidString
        
        let StorageRef = Storage.storage().reference().child("ImageUserMenu").child("\(ImageName).png")
        
        if let uploadData = self.imageViewFood.image!.pngData() {
            StorageRef.putData(uploadData, metadata: nil, completion: { (metaData, error) in
                if error != nil{
                    print(error!)
                    return
                }
                
                StorageRef.downloadURL { (url, error) in
                    if let downloadURL = url?.absoluteString {
                        self.urlImgaString = downloadURL
                    }
                    else {
                        
                        return
                    }
                }
                
                
            })
        }
        
        picker.dismiss(animated: true, completion: nil)
        
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
        print("canceled piker")
    }
    
    @IBAction func AddMenuStore(_ sender: Any) {
        myMenu.urlimg = urlImgaString
        myMenu.namefood = txtNameFood.text!
        myMenu.price = txtPrice.text!
        isCheck = true
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func Cancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
