//
//  CommentTableViewCell.swift
//  GiaoDien
//
//  Created by TrucRocket on 6/8/19.
//  Copyright © 2019 Cuong. All rights reserved.
//

import UIKit

class CommentTableViewCell: UITableViewCell {

    @IBOutlet weak var commentStore: UILabel!
    @IBOutlet weak var nameAvartar: UILabel!
    @IBOutlet weak var imageAvatar: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
